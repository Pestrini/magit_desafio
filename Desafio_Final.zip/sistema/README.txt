Sistema Criado para empresa MAGIT como projeto avaliativo da Universidade de Ribeirão Preto (UNAERP).

Desenvolvido pelos alunos:
Diego Torini - 832056
Gabriel Pestrini - 828420
Guilherme Martins - 831963
Natan Laci - 828177

