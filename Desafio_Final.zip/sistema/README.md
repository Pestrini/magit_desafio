<p align="center">

</p>

<h3 align="center">UNAERP</h3>

<p align="center">
  Sistema Criado para empresa MAGIT como projeto avaliativo da Universidade de Ribeirão Preto (UNAERP).
  <br>
  Desenvolvido pelos alunos:
  <br>
  Diego Daniel Torini - 832056
  Gabriel Henrique Pereira Pestrini - 828420
  Guilherme Martins Ferreira - 831963
  Natan Laci Dutra Araujo - 828177
  <br>
</p>